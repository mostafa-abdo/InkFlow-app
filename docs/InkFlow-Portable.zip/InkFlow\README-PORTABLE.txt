InkFlow — Portable (Windows)
=============================

Arabic (العربية)
----------------
InkFlow هو تطبيق تدوين ملاحظات وكتابة رقمية احترافي يعمل بالكامل بدون اتصال بالإنترنت.

"التثبيت" (ليست بحاجة للتثبيت):
1. فك الضغط عن هذه المجلد
2. افتح الملف InkFlow.html في Microsoft Edge أو Google Chrome
3. للإحساس بالتطبيق الكامل (بدون شريط عنوان): من قائمة المتصفح اختر "تثبيت InkFlow" (Install)

قلم الضغط المثبت على صفحة:
- افتح الصفحة كما في الخطوة 2 ثم ابدأ الكتابة بقلم الستايلس
- اختصار "E + 1" = ممحاة كاملة، "E + 2" = ممحاة جزئية
- اختصارات الأدوات: P قلم · B رصاص · H تظليل · V تحديد · L لاسو
- Ctrl+Z تراجع · Ctrl+Shift+Z إعادة · Ctrl+F بحث الملاحظات

ملاحظة مهمة: بياناتك تُحفظ محلياً على جهازك فقط (IndexedDB). لا شيء يُرفع لأي خادم.

English
-------
InkFlow is an offline digital handwriting and note-taking app for graphics tablets.

"Install" (no installer needed):
1. Unzip this folder anywhere
2. Open InkFlow.html in Microsoft Edge or Google Chrome
3. For a full app experience: from the browser menu choose "Install InkFlow…"

Writing inside InkFlow:
- Press down ink pen — strength controls line width (like real pen)
- Eraser: "E+1" deletes the whole stroke under it, "E+2" trims only what it touches
- Keyboard: P pen · B pencil · H highlighter · V select · L lasso · Ctrl+Z undo

Privacy: your notes never leave your device. Storage is local (IndexedDB).
